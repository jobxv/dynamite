import AuthForm from "@/components/ui/AuthForm";

export default function page() {
  return <AuthForm type="signin" />;
}
