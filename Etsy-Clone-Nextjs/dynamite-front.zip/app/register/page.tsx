import AuthForm from "@/components/ui/AuthForm";

const page = () => {
  return <AuthForm type="register" />;
};

export default page;
