import React from 'react';
import Footer from "./Footer";

const ClientFooterWrapper = () => {
  return <Footer />;
};

export default ClientFooterWrapper;